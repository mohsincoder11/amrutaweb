<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grnrow extends Model
{
	protected $fillable=['grnrefid2','item','rate','quantity','noofbird','avgbodywt','amount','labor',];
 }
