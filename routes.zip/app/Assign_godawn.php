<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assign_godawn extends Model
{
        protected $fillable=['user_id','godawns'];

}
