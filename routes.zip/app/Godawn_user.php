<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Godawn_user extends Model
{
    protected $fillable=['user_id','gtog','stos','stog','dailyentry','purchase','daily_supervision','distribute','grn'];
}
