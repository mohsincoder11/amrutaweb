<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Area_master extends Model
{
    protected $fillable = [
    'area','shop_id',
];
}
