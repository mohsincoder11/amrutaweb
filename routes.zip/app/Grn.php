<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grn extends Model
{
        protected $fillable=['grnid','grnrefid','godawn','dateofpur','vendor','vehno','drivername','transmornos','transmorwt',]; 

}
