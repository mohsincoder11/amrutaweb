<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Promotional_images extends Model
{
    protected $fillable=['image','name'];
}
