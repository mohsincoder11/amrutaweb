<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Time_slot extends Model
{
    protected $fillable=['day','status'];
}
