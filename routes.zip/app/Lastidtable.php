<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lastidtable extends Model
{
    //
    protected $fillable = [
        'lastid','shopid',
    ];
}
