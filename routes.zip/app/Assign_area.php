<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assign_area extends Model
{
    protected $fillable=['shop_id','assign_area'];
}
