<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Godawn extends Model
{
protected $fillable=['address','geolocation','pername','godawnname','mobno','capacity','opening_birds','birds_weights','assign_status'];
}
