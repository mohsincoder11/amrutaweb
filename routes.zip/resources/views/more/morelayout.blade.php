<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">
                        <div class="col-md-12" align="center" style="margin-top:-12px;">
                            <h5 style="color:#000; background-color:#FFCC00; width:15%; min-height:25px; padding-top:5px;" align="center"><span class="fa fa-user"></span> <strong>More Dashboard</strong></h5>
                        </div>
                        
                        
                        <div class="col-md-12" style="margin-bottom:-5px;" align="center">
                            
                                 <a href="{{route('grn')}}"> <button type="button" class="btn active" style="background-color:#006699; color:#FFFFFF"><i class="fa fa-sticky-note-o" aria-hidden="true"></i>
GRN(Goods Received Note)</button></a>
                            <a href="{{route('purchaseform')}}"><button type="button" class="btn active" style="background-color:#ff0066; color:#FFFFFF"><i class="fa fa-file-text" aria-hidden="true"></i>
Purchase Form</button></a>
              <a href="{{route('dailysuper')}}"><button type="button" class="btn btn-danger active"><i class="fa fa-user-secret" aria-hidden="true"></i>
 Daily Supervision</button></a>
              <a href="{{route('distribute')}}"><button type="button" class="btn btn-primary active"><i class="fa fa-shopping-bag" aria-hidden="true"></i>
Distribute to Shop/Cutting Unit</button></a> 
            <!--   <a href="{{route('dailyentry')}}"> <button type="button" class="btn " style="background-color:#2fa890; color:#FFFFFF"><i class="fa fa-pencil-square" aria-hidden="true"></i>
Daily Entry for Shop</button></a> -->
                            <a href="{{route('godowntogodown')}}"><button type="button" class="btn active" style="background-color:#ff0066; color:#FFFFFF"><i class="fa fa-building-o" aria-hidden="true"></i>

Godawn to Godawn Transfer</button></a>
             <!--  <a href="{{route('shoptoshop')}}"><button type="button" class="btn " style="background-color: #996633;color: #fff"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>

 Shop to Shop Transfer</button></a> -->
             <!--  <a href="{{route('shoptogodown')}}"><button type="button" class="btn " style="background-color: #1b611f;color: #fff"><i class="fa fa-truck" aria-hidden="true"></i>
 Shop to Godawn Transfer</button></a>   -->                                     
            </div>



          </div>
        </div>
      </div>



    </div>
  </div>