<div class="row">
    <div class="col-md-12 col-sm-12">
      <div class="panel panel-default">
       <div class="panel-body">
        <div class="form-group">
          <div class="col-md-12 col-sm-12" align="center">
            <h5 style="color:#000; background-color:#FFCC00; width:15%; min-height:25px; padding-top:5px;" align="center"><span class="fa fa-users"></span> <strong>Users Management</strong></h5>
          </div>
            <div class="col-md-12" style="margin-bottom:-5px;" align="center">
              
              <a href="{{route('usermanage')}}"> <button type="button" class="btn active" style="background-color:#A43F3E; color:#FFFFFF"><i class="fa fa-shopping-bag"></i>Shop/Telecaller </button></a>
              <a href="{{route('godawn_user')}}"><button type="button" class="btn" style="background-color: #006699;color: #fff;"><i class="fa fa-exchange"></i>Godawn User</button></a>   
                            <a href="{{route('assign_godawn')}}"><button type="button" class="btn active" style="background-color:#ff0066; color:#FFFFFF"><i class="fa fa-pencil"></i>Assign Godwan</button></a>
                                             
                                                          
            </div>

        </div>
      </div>
    </div>



  </div>
</div>