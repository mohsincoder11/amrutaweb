<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="form-group">
						<div class="col-md-12" align="center" style="margin-top:-12px;">
							<h5 style="color:#000; background-color:#FFCC00; width:15%; min-height:25px; padding-top:5px;" align="center"><span class="fa fa-user"></span> <strong>Master Dashboard</strong></h5>
						</div>
						
						
						<div class="col-md-12" style="margin-bottom:-5px;" align="center">
							
						  <a href="{{route('addcustomer')}}"> <button type="button" class="btn active" style="background-color:#006699; color:#FFFFFF"><i class="fa fa-users"></i>Add Customers</button></a>
              <a href="{{route('additem')}}"><button type="button" class="btn active" style="background-color:#ff0066; color:#FFFFFF"><i class="fa fa-pencil"></i>Add Items</button></a>
               <a href="{{route('addpromotional_image')}}"> <button type="button" class="btn active" style="background-color:#630947; color:#FFFFFF"><i class="fa fa-image"></i>Add Promotional Img</button></a>
               <a href="{{url('coupon_master')}}"> <button type="button" class="btn active" style="background-color:#0b4208; color:#FFFFFF"><i class="fa fa-percent"></i>Coupon Master</button></a>
           
              <a href="{{route('addshop')}}"><button type="button" class="btn btn-danger active"><i class="fa fa-bank"></i> Shops</button></a>
               <a href="{{route('addarea')}}"><button type="button" class="btn" style="background-color: #3b1540;color: #fff"><i class="fa fa-map-marker" aria-hidden="true"></i> Area</button></a> 
               <a href="{{route('assign_area')}}"><button type="button" class="btn" style="background-color: #909176;color: #fff"><i class="fa fa-check" aria-hidden="true"></i> Assign Area</button></a> 
                <a href="{{route('time_slot')}}"><button type="button" class="btn" style="background-color: #ba7f1a;color: #fff"><i class="fa fa-clock-o" aria-hidden="true"></i> Time Slot</button></a> 
              <a href="{{route('deliveryboy')}}"><button type="button" class="btn btn-primary active"><i class="fa fa-user-circle"></i>Add Delivery Boy</button></a>                                                
              <a href="{{route('addgodawn')}}"><button type="button" class="btn btn-primary active" style="background-color: #849429"><i class="fa fa-building" aria-hidden="true"></i>
Add Godawn</button></a>                                                
              <a href="{{route('addvendor')}}"><button type="button" class="btn btn-primary active" style="background-color: #c93f18"><i class="fa fa-male" aria-hidden="true"></i>
Add Vendor</button></a>                                                
              <a href="{{route('addunit')}}"><button type="button" class="btn btn-primary active" style="background-color: #267a75"><i class="fa fa-viacoin" aria-hidden="true"></i>
Add Unit</button></a>                                                
            </div>



          </div>
        </div>
      </div>



    </div>
  </div>